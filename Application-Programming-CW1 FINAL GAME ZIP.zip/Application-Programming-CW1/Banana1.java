import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)



public class Banana1 extends Characters
{

    public void act()
    {
        
    }

}
